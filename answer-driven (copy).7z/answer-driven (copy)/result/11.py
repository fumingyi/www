f_style =open("./src1.txt", 'a')
i = 1
for i in range(1, 7838):
    f_style.write(str(i) + "\n")
    i = i+1
f_style.close()