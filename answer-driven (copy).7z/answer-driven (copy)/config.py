# # train file
# train_src_file = "./squad-60/train_src60.txt"
# train_trg_file = "./squad-60/train_tgt60.txt"
# train_bio_file = "./squad-60/train_bio60.txt"
# train_adj_file = "./squad-60/train_60_adj.txt"
# train_ner_file = "./squad-60/train_ner60.txt"
# train_style_file = "./squad-60/train_q_style-60.txt"
# # dev file
# dev_src_file = "./squad-60/dev_src60.txt"
# dev_trg_file = "./squad-60/dev_tgt60.txt"
# dev_bio_file = "./squad-60/dev_bio60.txt"
# dev_adj_file = "./squad-60/dev_60_adj.txt"
# dev_ner_file = "./squad-60/dev_ner60.txt"
# dev_style_file = "./squad-60/dev_q_style-60.txt"
# # test file
# # test_src_file = "./squad-60/test_src60.txt"
# # test_trg_file = "./squad-60/test_tgt60.txt"
# # test_bio_file = "./squad-60/test_bio60.txt"
# # test_adj_file = "./squad-60/test_60_adj.txt"
# # test_ner_file = "./squad-60/test_ner60.txt"
# # test_style_file = "./squad-60/test_q_style-60.txt"
# test_src_file = "./squad-60/dev_src60.txt"
# test_trg_file = "./squad-60/dev_tgt60.txt"
# test_bio_file = "./squad-60/dev_bio60.txt"
# test_adj_file = "./squad-60/dev_60_adj.txt"
# test_ner_file = "./squad-60/dev_ner60.txt"
# test_style_file = "./squad-60/dev_q_style-60.txt"
# embedding and dictionary file
# train file
train_src_file = "./squad/split1-8.25/train_src50.txt"
train_trg_file = "./squad/split1-8.25/train_tgt50.txt"
train_bio_file = "./squad/split1-8.25/train_bio50.txt"
train_adj_file = "./squad/split1-8.25/train_split1.1_adj50.txt"
train_ner_file = "./squad/split1-8.25/train_ner50.txt"
train_style_file = "./squad/split1-8.25/train_q_style.txt"
train_an_file = "./squad/split1-8.25/train_answer50bio.txt"
train_pos_file = "./squad/split1-8.25/train_pos50.txt"
# dev file
dev_src_file = "./squad/split1-8.25/dev_src50.txt"
dev_trg_file = "./squad/split1-8.25/dev_tgt50.txt"
dev_bio_file = "./squad/split1-8.25/dev_bio50.txt"
dev_adj_file = "./squad/split1-8.25/dev_split1.1_adj50.txt"
dev_ner_file = "./squad/split1-8.25/dev_ner50.txt"
dev_style_file = "./squad/split1-8.25/dev_q_style.txt"
dev_an_file = "./squad/split1-8.25/dev_answer50bio.txt"
dev_pos_file = "./squad/split1-8.25/dev_pos50.txt"
# test file
test_src_file = "./squad/test_src50.txt"
test_trg_file = "./squad/test_tgt50.txt"
test_bio_file = "./squad/test_bio50.txt"
test_adj_file = "./squad/test_adj.txt"
test_ner_file = "./squad/test_ner50.txt"
test_style_file = "./squad/test_q_style.txt"
test_an_file = "./squad/test_answer50bio.txt"
test_pos_file = "./squad/test_pos50.txt"

embedding = "./data/embedding.pkl"
word2idx_file = "./data/word2idx.pkl"

model_path = "./save/seq2seq/train_826214740/17_2.78"
train = False   #设置是否为train模式
device = "cuda:1"
use_gpu = True
debug = False
vocab_size = 45000
freeze_embedding = True

num_epochs = 30
max_len = 100
num_layers = 2
hidden_size = 300
d_inner = 2048
embedding_size = 300
d_model = 600
lr = 0.1
batch_size = 64
dropout = 0.2
max_grad_norm = 5.0

use_pointer = True
beam_size = 12
min_decode_step = 8
max_decode_step = 30
output_dir = "./result/"
